// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright contributors to the vLLM project

use std::fmt;
use std::str::FromStr;

use itertools::Itertools;
use serde_with::{DeserializeFromStr, SerializeDisplay};
use strum::{EnumIter, IntoEnumIterator};

/// Specify which chat renderer implementation to use.
#[derive(
    Debug, Clone, Copy, PartialEq, Eq, Default, DeserializeFromStr, SerializeDisplay, EnumIter,
)]
pub enum RendererSelection {
    /// Use model-based auto-detection.
    #[default]
    Auto,
    /// Force the generic Hugging Face chat-template renderer.
    Hf,
    /// Force the DeepSeek V3.2 renderer.
    DeepSeekV32,
    /// Force the DeepSeek V4 renderer.
    DeepSeekV4,
    /// Force the DeepSeek V4.1 renderer.
    DeepSeekV41,
    /// Force the GPT-OSS Harmony renderer.
    Harmony,
    /// Force the Inkling native token renderer.
    Inkling,
    /// Force the Kimi K3 XTML renderer.
    KimiK3,
}

impl RendererSelection {
    pub const AUTO_LITERAL: &str = "auto";
    pub const DEEPSEEK_V32_LITERAL: &str = "deepseek_v32";
    pub const DEEPSEEK_V4_LITERAL: &str = "deepseek_v4";
    pub const DEEPSEEK_V41_LITERAL: &str = "deepseek_v41";
    pub const GPT_OSS_MODEL_TYPE: &str = "gpt_oss";
    pub const HARMONY_LITERAL: &str = "harmony";
    pub const HF_LITERAL: &str = "hf";
    pub const INKLING_LITERAL: &str = "inkling";
    pub const INKLING_MODEL_TYPE: &str = "inkling_mm_model";
    pub const KIMI_K3_LITERAL: &str = "kimi_k3";

    /// Resolve the renderer selection using the given model type string, if
    /// it's `Auto`.
    pub fn resolve(self, model_type: &str) -> Self {
        match self {
            Self::Auto => match model_type {
                Self::DEEPSEEK_V32_LITERAL => Self::DeepSeekV32,
                Self::DEEPSEEK_V4_LITERAL => Self::DeepSeekV4,
                Self::DEEPSEEK_V41_LITERAL => Self::DeepSeekV41,
                Self::GPT_OSS_MODEL_TYPE => Self::Harmony,
                Self::INKLING_MODEL_TYPE => Self::Inkling,
                Self::KIMI_K3_LITERAL => Self::KimiK3,
                _ => Self::Hf,
            },
            selection => selection,
        }
    }
}

impl FromStr for RendererSelection {
    type Err = String;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        if value.eq_ignore_ascii_case(Self::AUTO_LITERAL) {
            Ok(Self::Auto)
        } else if value.eq_ignore_ascii_case(Self::HF_LITERAL) {
            Ok(Self::Hf)
        } else if value.eq_ignore_ascii_case(Self::DEEPSEEK_V32_LITERAL) {
            Ok(Self::DeepSeekV32)
        } else if value.eq_ignore_ascii_case(Self::DEEPSEEK_V4_LITERAL) {
            Ok(Self::DeepSeekV4)
        } else if value.eq_ignore_ascii_case(Self::DEEPSEEK_V41_LITERAL) {
            Ok(Self::DeepSeekV41)
        } else if value.eq_ignore_ascii_case(Self::HARMONY_LITERAL) {
            Ok(Self::Harmony)
        } else if value.eq_ignore_ascii_case(Self::INKLING_LITERAL) {
            Ok(Self::Inkling)
        } else if value.eq_ignore_ascii_case(Self::KIMI_K3_LITERAL) {
            Ok(Self::KimiK3)
        } else {
            Err(format!(
                "unknown renderer `{value}` (expected one of: {})",
                Self::iter().join(", ")
            ))
        }
    }
}

impl fmt::Display for RendererSelection {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Auto => f.write_str(Self::AUTO_LITERAL),
            Self::Hf => f.write_str(Self::HF_LITERAL),
            Self::DeepSeekV32 => f.write_str(Self::DEEPSEEK_V32_LITERAL),
            Self::DeepSeekV4 => f.write_str(Self::DEEPSEEK_V4_LITERAL),
            Self::DeepSeekV41 => f.write_str(Self::DEEPSEEK_V41_LITERAL),
            Self::Harmony => f.write_str(Self::HARMONY_LITERAL),
            Self::Inkling => f.write_str(Self::INKLING_LITERAL),
            Self::KimiK3 => f.write_str(Self::KIMI_K3_LITERAL),
        }
    }
}

#[cfg(test)]
mod tests {
    use std::str::FromStr as _;

    use strum::IntoEnumIterator;

    use super::RendererSelection;

    #[test]
    fn renderer_selection_display_round_trips() {
        for selection in RendererSelection::iter() {
            assert_eq!(
                selection.to_string().parse::<RendererSelection>().unwrap(),
                selection
            );
        }
    }

    #[test]
    fn renderer_selection_expected_error_message() {
        let err = RendererSelection::from_str("unknown").unwrap_err();
        expect_test::expect![
            "unknown renderer `unknown` (expected one of: auto, hf, deepseek_v32, deepseek_v4, deepseek_v41, harmony, inkling, kimi_k3)"
        ]
        .assert_eq(&err);
    }
}
