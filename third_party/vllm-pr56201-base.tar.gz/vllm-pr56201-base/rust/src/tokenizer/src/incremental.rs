// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright contributors to the vLLM project

use crate::{Result, Tokenizer};

mod attribution;

use attribution::AttributedTextBuffer;
pub use attribution::{DecodedText, TokenAnchor, TokenAttribution};

/// Stateful incremental decoder that emits text chunks one token at a time.
pub trait IncrementalDecoder: Send {
    /// Push one generated token and return how many new string bytes were
    /// added.
    fn push_token(&mut self, token_id: u32) -> Result<usize>;

    /// Consume any text which is currently ready.
    fn next_chunk(&mut self) -> Option<DecodedText>;

    /// Flush any remaining buffered text that has not yet been emitted.
    ///
    /// Called after the final generated token to force out buffered/incomplete
    /// fragments.
    fn flush(
        &mut self,
        truncate_output_to: Option<usize>,
    ) -> Result<(Option<DecodedText>, DecodedText)>;

    /// Return cumulative decoded text so far.
    fn output(&self) -> &str;
}

/// [`IncrementalDecoder`] built on [`Tokenizer::decode()`] with prefix-diffing.
///
/// This is the same sliding-window algorithm used by `tokenizers::DecodeStream`
pub(crate) struct DecodeStream<'a, T: Tokenizer + ?Sized> {
    tokenizer: &'a T,
    skip_special_tokens: bool,
    min_bytes_to_buffer: usize,
    // mutated state
    ids: Vec<u32>,
    prefix: String,
    prefix_index: usize,
    prefix_seeded: bool,
    decoded: AttributedTextBuffer,
}

impl<'a, T: Tokenizer + ?Sized> DecodeStream<'a, T> {
    pub(crate) fn new(
        tokenizer: &'a T,
        prompt_token_ids: &[u32],
        skip_special_tokens: bool,
        min_bytes_to_buffer: usize,
    ) -> Self {
        Self {
            tokenizer,
            skip_special_tokens,
            min_bytes_to_buffer,
            ids: prompt_token_ids.to_vec(),
            prefix: String::new(),
            prefix_index: 0,
            prefix_seeded: prompt_token_ids.is_empty(),
            decoded: AttributedTextBuffer::default(),
        }
    }
}

/// Try a short tail suffix first (covers a CJK glyph straddling 1-2 token
/// boundaries); beyond 6 tokens the fallback full-prompt decode is no worse
/// than baseline so widening the sweep just adds overhead.
const SAFE_SUFFIX_MIN: usize = 4;
const SAFE_SUFFIX_MAX: usize = 6;

impl<T: Tokenizer + ?Sized> DecodeStream<'_, T> {
    fn record_token(&mut self, token_id: u32) {
        if self.skip_special_tokens && self.tokenizer.is_special_id(token_id) {
            self.decoded.record_zero_width_token(token_id);
        } else {
            self.decoded.record_pending_token(token_id);
        }
    }

    /// Decode prompt-only context for prefix seeding.
    ///
    /// Prompt ids may come from the model vocabulary rather than the local
    /// tokenizer vocabulary. For this seeding path, ids that cannot be mapped
    /// back to raw token text are dropped before retrying strict decode. This
    /// tolerance is intentionally limited to prompt context; generated ids are
    /// decoded later through the normal strict path.
    fn decode_prompt_context(&self, ids: &[u32]) -> Result<(String, Vec<u32>)> {
        match self.tokenizer.decode(ids, self.skip_special_tokens) {
            Ok(decoded) => Ok((decoded, ids.to_vec())),
            Err(error) => {
                let filtered = ids
                    .iter()
                    .copied()
                    .filter(|&id| self.tokenizer.id_to_token(id).is_some())
                    .collect::<Vec<_>>();
                if filtered.len() == ids.len() {
                    return Err(error);
                }
                self.tokenizer
                    .decode(&filtered, self.skip_special_tokens)
                    .map(|decoded| (decoded, filtered))
            }
        }
    }

    /// Seed `self.prefix` from the shortest trailing prompt suffix whose
    /// filtered context is still long enough and whose decoded text has no
    /// U+FFFD. A clean decode means the suffix starts and ends at valid
    /// UTF-8/token boundaries, so priming from it is equivalent to priming from
    /// the full prompt.
    fn seed_prefix(&mut self) -> Result<()> {
        let prompt_len = self.ids.len();
        if prompt_len > SAFE_SUFFIX_MIN {
            let max_try = SAFE_SUFFIX_MAX.min(prompt_len - 1);
            for suffix_len in SAFE_SUFFIX_MIN..=max_try {
                let start = prompt_len - suffix_len;
                let (decoded, context_ids) = self.decode_prompt_context(&self.ids[start..])?;
                if !decoded.contains('\u{FFFD}') && context_ids.len() >= SAFE_SUFFIX_MIN {
                    self.prefix = decoded;
                    self.ids = context_ids;
                    self.prefix_index = self.ids.len();
                    return Ok(());
                }
            }
        }
        let (decoded, context_ids) = self.decode_prompt_context(&self.ids)?;
        self.ids = context_ids;
        if !decoded.ends_with('\u{FFFD}') {
            self.prefix = decoded;
            self.prefix_index = self.ids.len();
        }
        Ok(())
    }
}

impl<T: Tokenizer + ?Sized> IncrementalDecoder for DecodeStream<'_, T> {
    fn push_token(&mut self, token_id: u32) -> Result<usize> {
        if !self.prefix_seeded && !self.ids.is_empty() {
            self.seed_prefix()?;
            self.prefix_seeded = true;
        }

        self.ids.push(token_id);
        self.record_token(token_id);
        let string = self.tokenizer.decode(&self.ids, self.skip_special_tokens)?;
        let prefix_len = self.prefix.len();
        if string.len() <= prefix_len || string.ends_with('\u{FFFD}') {
            return Ok(0);
        }
        // Ensure we split at a utf-8 char boundary.
        let new_chunk = &string[string.floor_char_boundary(prefix_len)..];
        self.decoded.append_visible_text(new_chunk);
        self.ids.drain(..self.prefix_index);
        self.prefix = self.tokenizer.decode(&self.ids, self.skip_special_tokens)?;
        self.prefix_index = self.ids.len();
        Ok(new_chunk.len())
    }

    fn next_chunk(&mut self) -> Option<DecodedText> {
        let cutoff = self.decoded.len().saturating_sub(self.min_bytes_to_buffer);
        // Ensure we split at a utf-8 char boundary.
        let cutoff = self.decoded.text().floor_char_boundary(cutoff);
        self.decoded.take_ready(cutoff)
    }

    fn flush(
        &mut self,
        truncate_output_to: Option<usize>,
    ) -> Result<(Option<DecodedText>, DecodedText)> {
        // If the prefix was never seeded (no push_token was called), `ids`
        // holds only prompt context — decoding it would re-emit prompt text.
        if self.prefix_seeded && !self.ids.is_empty() {
            let string = self.tokenizer.decode(&self.ids, self.skip_special_tokens)?;
            let prefix_len = self.prefix.len();
            // Ensure we split at a utf-8 char boundary.
            let new_chunk = &string[string.floor_char_boundary(prefix_len)..];
            if !new_chunk.is_empty() {
                self.decoded.append_visible_text(new_chunk);
            }
        }
        self.decoded.resolve_pending_zero_width();
        self.ids.clear();
        self.prefix.clear();
        self.prefix_index = 0;
        self.prefix_seeded = true;
        if let Some(truncate_output_to) = truncate_output_to {
            self.decoded.truncate(truncate_output_to);
        }
        Ok(self.decoded.finish())
    }

    fn output(&self) -> &str {
        self.decoded.text()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_utils::TestTokenizer;

    /// Backend that treats each token ID as a raw byte, producing lossy UTF-8.
    #[derive(Debug)]
    struct Utf8Backend;

    impl Tokenizer for Utf8Backend {
        fn encode(&self, _text: &str, _add_special_tokens: bool) -> Result<Vec<u32>> {
            unreachable!()
        }

        fn encode_ordinary(&self, _text: &str) -> Result<Vec<u32>> {
            unreachable!()
        }

        fn decode(&self, token_ids: &[u32], _skip_special_tokens: bool) -> Result<String> {
            let bytes = token_ids.iter().map(|id| *id as u8).collect::<Vec<_>>();
            Ok(String::from_utf8_lossy(&bytes).into_owned())
        }

        fn token_to_id(&self, _token: &str) -> Option<u32> {
            unreachable!()
        }

        fn id_to_token(&self, _id: u32) -> Option<String> {
            unreachable!()
        }
    }

    #[test]
    fn holds_incomplete_utf8_until_complete() {
        let backend = Utf8Backend;
        let mut decoder = backend.create_decode_stream(&[], false, 0);

        // 你 = U+4F60 = 0xE4 0xBD 0xA0
        assert_eq!(decoder.push_token(0xe4).unwrap(), 0);
        assert_eq!(decoder.push_token(0xbd).unwrap(), 0);
        assert_eq!(decoder.push_token(0xa0).unwrap(), 3); // "你" is 3 bytes
        assert_eq!(decoder.output(), "你");
    }

    #[test]
    fn emits_ascii_immediately() {
        let backend = Utf8Backend;
        let mut decoder = backend.create_decode_stream(&[], false, 0);

        assert_eq!(decoder.push_token(b'o' as u32).unwrap(), 1);
        assert_eq!(decoder.push_token(b'k' as u32).unwrap(), 1);
        assert_eq!(decoder.output(), "ok");
    }

    #[test]
    fn flush_returns_none_when_fully_consumed() {
        let backend = Utf8Backend;
        let mut decoder = backend.create_decode_stream(&[], false, 0);

        assert_eq!(decoder.push_token(b'o' as u32).unwrap(), 1);
        assert_eq!(decoder.next_chunk().unwrap().text, "o");
        assert_eq!(decoder.push_token(b'k' as u32).unwrap(), 1);
        assert_eq!(decoder.next_chunk().unwrap().text, "k");
        // All text already consumed via next_chunk
        let (last_chunk, full_text) = decoder.flush(None).unwrap();
        assert_eq!(last_chunk, None);
        assert_eq!(full_text.text, "ok");
    }

    #[test]
    fn flush_emits_buffered_incomplete_utf8() {
        let backend = Utf8Backend;
        let mut decoder = backend.create_decode_stream(&[], false, 0);

        // Push incomplete multi-byte sequence — step returns 0 bytes.
        assert_eq!(decoder.push_token(0xe4).unwrap(), 0);
        assert_eq!(decoder.push_token(0xbd).unwrap(), 0);

        // Flush forces out whatever the decoder can produce (lossy replacement).
        let (last_chunk, _full_text) = decoder.flush(None).unwrap();
        assert!(last_chunk.is_some());
    }

    /// Backend where token 0 is a special token.
    #[derive(Debug)]
    struct SpecialTokenBackend;

    impl Tokenizer for SpecialTokenBackend {
        fn encode(&self, _text: &str, _add_special_tokens: bool) -> Result<Vec<u32>> {
            unreachable!()
        }

        fn encode_ordinary(&self, _text: &str) -> Result<Vec<u32>> {
            unreachable!()
        }

        fn decode(&self, token_ids: &[u32], skip_special_tokens: bool) -> Result<String> {
            let mut text = String::new();
            for &token_id in token_ids {
                match token_id {
                    0 if !skip_special_tokens => text.push_str("<special>"),
                    0 => {}
                    1 => text.push('a'),
                    2 => text.push('b'),
                    _ => {}
                }
            }
            Ok(text)
        }

        fn token_to_id(&self, _token: &str) -> Option<u32> {
            unreachable!()
        }

        fn id_to_token(&self, _id: u32) -> Option<String> {
            unreachable!()
        }

        fn is_special_id(&self, token_id: u32) -> bool {
            token_id == 0
        }
    }

    #[test]
    fn respects_skip_special_tokens() {
        let backend = SpecialTokenBackend;
        let mut skip_decoder = backend.create_decode_stream(&[], true, 0);
        let mut keep_decoder = backend.create_decode_stream(&[], false, 0);

        assert_eq!(skip_decoder.push_token(0).unwrap(), 0);
        assert_eq!(keep_decoder.push_token(0).unwrap(), 9); // "<special>" is 9 bytes
        assert_eq!(keep_decoder.output(), "<special>");
    }

    #[test]
    fn prompt_tokens_provide_context_without_re_emission() {
        let backend = Utf8Backend;
        let prompt = &[b'H' as u32, b'i' as u32];
        let mut decoder = backend.create_decode_stream(prompt, false, 0);

        // First generated token should not re-emit "Hi".
        let added = decoder.push_token(b'!' as u32).unwrap();
        assert_eq!(added, 1);
        assert_eq!(decoder.output(), "!");
    }

    #[test]
    fn prompt_context_filters_unknown_ids() {
        let tokenizer = TestTokenizer::new();
        assert_eq!(tokenizer.id_to_token(10_000), None);

        let cases: &[(&str, &[u32], u32, &str)] = &[
            (
                "suffix seed",
                &[
                    b'a' as u32,
                    b'b' as u32,
                    b'c' as u32,
                    10_000,
                    b'H' as u32,
                    b'i' as u32,
                ],
                b'!' as u32,
                "!",
            ),
            ("all unknown", &[10_000], b'!' as u32, "!"),
            (
                "unknown before incomplete utf-8",
                &[10_000, 0xe4, 0xbd],
                0xa0,
                "你",
            ),
            (
                "incomplete utf-8 before filtered suffix",
                &[0xe4, 0xbd, 10_000, 10_001, 10_002, 10_003, 10_004, 10_005],
                0xa0,
                "你",
            ),
        ];

        for &(name, prompt, token_id, output) in cases {
            let mut decoder = tokenizer.create_decode_stream(prompt, false, 0);
            assert_eq!(
                decoder.push_token(token_id).unwrap(),
                output.len(),
                "{name}"
            );
            assert_eq!(decoder.output(), output, "{name}");
        }
    }

    #[test]
    fn generated_unknown_ids_still_return_decode_error() {
        let tokenizer = TestTokenizer::new();
        assert_eq!(tokenizer.id_to_token(10_000), None);

        let prompt = &[10_000, b'H' as u32, b'i' as u32];
        let mut decoder = tokenizer.create_decode_stream(prompt, false, 0);

        let error = decoder.push_token(10_000).unwrap_err();
        assert!(
            error
                .to_string()
                .contains("test tokenizer cannot decode unknown token id 10000")
        );
    }

    #[test]
    fn chunks_concatenate_to_full_text() {
        let backend = Utf8Backend;
        let mut decoder = backend.create_decode_stream(&[], false, 0);

        let input = b"Hello, world!";
        let mut out = String::new();
        for &byte in input {
            decoder.push_token(byte as u32).unwrap();
            if let Some(chunk) = decoder.next_chunk() {
                out.push_str(&chunk.text);
            }
        }
        let (last_chunk, full) = decoder.flush(None).unwrap();
        assert_eq!(last_chunk, None); // all consumed via next_chunk
        assert_eq!(out, "Hello, world!");
        assert_eq!(full.text, "Hello, world!");
    }

    /// Backend simulating non-monotonic decode where adding a token changes how
    /// earlier tokens decode (context-dependent normalization), causing
    /// prefix_len to land mid-UTF-8. Reproduces the class of bug from
    /// vllm-project/vllm#17448.
    #[derive(Debug)]
    struct NonMonotonicBackend;

    impl Tokenizer for NonMonotonicBackend {
        fn encode(&self, _text: &str, _add_special_tokens: bool) -> Result<Vec<u32>> {
            unreachable!()
        }

        fn encode_ordinary(&self, _text: &str) -> Result<Vec<u32>> {
            unreachable!()
        }

        fn decode(&self, token_ids: &[u32], _skip_special_tokens: bool) -> Result<String> {
            match token_ids {
                [1] => Ok("abc".into()),
                [1, 2] => Ok("ab".into()),
                // Token 3 triggers a normalization change: "ab" becomes emoji + "d".
                // prefix_len=3 ("abc") lands inside the 4-byte emoji 🎉.
                [1, 2, 3] => Ok("🎉d".into()), // 🎉 is 4 bytes + d = 5 bytes
                [2, 3] => Ok("🎉d".into()),    // prefix recompute after drain
                [3] => Ok("d".into()),         // after drain
                _ => panic!("unexpected decode: {:?}", token_ids),
            }
        }

        fn token_to_id(&self, _token: &str) -> Option<u32> {
            unreachable!()
        }

        fn id_to_token(&self, _id: u32) -> Option<String> {
            unreachable!()
        }
    }

    /// Without the char-boundary fix, this panics slicing mid-emoji.
    #[test]
    fn non_monotonic_decode_does_not_panic() {
        let backend = NonMonotonicBackend;
        let mut decoder = backend.create_decode_stream(&[], false, 0);

        // Token 1: "abc", prefix="abc"
        assert_eq!(decoder.push_token(1).unwrap(), 3);
        // Token 2: "ab" (shorter), no emit
        assert_eq!(decoder.push_token(2).unwrap(), 0);
        // Token 3: "🎉d" — prefix_len=3 is mid-emoji. Without fix this panics.
        let added = decoder.push_token(3).unwrap();
        assert!(added > 0);
    }

    #[test]
    fn next_chunk_with_hold_back() {
        let backend = Utf8Backend;
        // hold_back_bytes: 3 means we buffer the last 3 bytes
        let mut decoder = backend.create_decode_stream(&[], false, 3);

        let input = b"Hello!";
        let mut chunks = String::new();
        for &byte in input {
            decoder.push_token(byte as u32).unwrap();
            if let Some(chunk) = decoder.next_chunk() {
                chunks.push_str(&chunk.text);
            }
        }
        // With hold_back_bytes=3, last 3 bytes ("lo!") are held back
        assert_eq!(chunks, "Hel");
        // Flush returns the rest
        let (last_chunk, full) = decoder.flush(None).unwrap();
        assert_eq!(last_chunk.unwrap().text, "lo!");
        assert_eq!(full.text, "Hello!");
    }

    #[test]
    fn next_chunk_cutoff_respects_char_boundary() {
        // Regression: next_chunk's cutoff (len - min_bytes_to_buffer) must be
        // aligned to a UTF-8 char boundary like push_token/flush; otherwise
        // streaming multi-byte output (CJK/emoji) with a hold-back buffer (set
        // by a stop string) panics slicing cumulative_output mid-character.
        let backend = Utf8Backend;
        let mut decoder = backend.create_decode_stream(&[], false, 2);
        let mut out = String::new();
        for byte in "你好A".bytes() {
            decoder.push_token(u32::from(byte)).unwrap();
            if let Some(chunk) = decoder.next_chunk() {
                out.push_str(&chunk.text);
            }
        }
        let (last_chunk, full) = decoder.flush(None).unwrap();
        if let Some(chunk) = last_chunk {
            out.push_str(&chunk.text);
        }
        assert_eq!(full.text, "你好A");
        assert_eq!(out, "你好A");
    }

    #[test]
    fn flush_without_push_token_does_not_leak_prompt() {
        let backend = Utf8Backend;
        let prompt: Vec<u32> = b"The quick brown fox jumps over the lazy dog. "
            .iter()
            .cycle()
            .take(7001)
            .map(|&b| b as u32)
            .collect();
        let mut decoder = backend.create_decode_stream(&prompt, false, 0);

        let (last_chunk, full) = decoder.flush(None).unwrap();
        assert_eq!(last_chunk, None);
        assert_eq!(full.text, "");
    }

    #[test]
    fn flush_without_push_token_does_not_leak_undecodable_prompt_tail() {
        let backend = Utf8Backend;
        let prompt = vec![0xe4, 0xbd];
        let mut decoder = backend.create_decode_stream(&prompt, false, 0);

        let (last_chunk, full) = decoder.flush(None).unwrap();
        assert_eq!(last_chunk, None);
        assert_eq!(full.text, "");
    }
}
