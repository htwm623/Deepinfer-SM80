// Stable-ABI migration: uses only torch::stable / torch::headeronly APIs.

#include <torch/csrc/stable/library.h>
#include <torch/csrc/stable/tensor.h>
#include <torch/csrc/stable/ops.h>
#include <torch/csrc/stable/accelerator.h>

#include <torch/headeronly/core/ScalarType.h>
#include <torch/headeronly/util/Exception.h>   // STD_TORCH_CHECK
#include <torch/headeronly/util/shim_utils.h>  // TORCH_ERROR_CODE_CHECK

#include <torch/csrc/inductor/aoti_torch/c/shim.h>  // aoti_torch_get_current_cuda_stream
#include <cuda_runtime.h>

#include <cstdint>
#include <limits>
#include <optional>
#include <tuple>
#include <vector>

#include <cutlass/numeric_types.h>

#include "namespace_config.h"
#include "hardware_info.h"
#include "flash_sparse.h"
#include "static_switch.h"

#define CHECK_DEVICE(x) STD_TORCH_CHECK(x.is_cuda(), #x " must be on CUDA")
#define CHECK_SHAPE(x, ...) STD_TORCH_CHECK(x.sizes().equals({__VA_ARGS__}), #x " must have shape (" #__VA_ARGS__ ")")
#define CHECK_CONTIGUOUS(x) STD_TORCH_CHECK(x.is_contiguous(), #x " must be contiguous")

namespace FLASH_NAMESPACE {

using torch::stable::Tensor;
using torch::headeronly::ScalarType;

// Stable-ABI replacement for at::cuda::getCurrentCUDAStream().stream().
static inline cudaStream_t get_current_cuda_stream(const Tensor &t) {
    void *stream_ptr = nullptr;
    TORCH_ERROR_CODE_CHECK(aoti_torch_get_current_cuda_stream(t.get_device_index(), &stream_ptr));
    return static_cast<cudaStream_t>(stream_ptr);
}

//
// Bit hacky but for now hook into the existing set_params_fprop,
// set_params_splitkv, and set_params_alibi in flash_api.cpp
//
void set_params_fprop(Flash_fwd_params &params,
                      // sizes
                      const size_t b,
                      const size_t seqlen_q,
                      const size_t seqlen_k,
                      const size_t seqlen_q_rounded,
                      const size_t seqlen_k_rounded,
                      const size_t h,
                      const size_t h_k,
                      const size_t d,
                      const size_t d_rounded,
                      // device pointers
                      const Tensor q,
                      const Tensor k,
                      const Tensor v,
                      Tensor out,
                      void *cu_seqlens_q_d,
                      void *cu_seqlens_k_d,
                      void *seqused_k,
                      void *p_d,
                      void *softmax_lse_d,
                      float p_dropout,
                      float softmax_scale,
                      int window_size_left,
                      int window_size_right,
                      const float softcap,
                      bool seqlenq_ngroups_swapped=false,
                      const bool unpadded_lse=false);

std::tuple<Tensor, Tensor> set_params_splitkv(Flash_fwd_params &params, const int batch_size,
    const int num_heads, const int head_size, const int max_seqlen_k, const int max_seqlen_q,
    const int head_size_rounded, const float p_dropout,
    const int num_splits, const int num_sm, const Tensor &ref);

void set_params_alibi(Flash_fwd_params &params, std::optional<Tensor> &alibi_slopes_, int batch_size, int num_heads);

///////////////////////////////////////////////////////////////////////////////

void set_params_fprop_sparse(Flash_fwd_params_sparse &params,
                            // sizes
                            const size_t b,
                            const size_t seqlen_q,
                            const size_t seqlen_k,
                            const size_t seqlen_q_rounded,
                            const size_t seqlen_k_rounded,
                            const size_t h,
                            const size_t h_k,
                            const size_t d,
                            const size_t d_rounded,
                            // device pointers
                            const Tensor q,
                            const Tensor k,
                            const Tensor v,
                            const Tensor block_count,
                            const Tensor block_offset,
                            const Tensor column_count,
                            const Tensor column_index,
                            Tensor out,
                            void *cu_seqlens_q_d,
                            void *cu_seqlens_k_d,
                            void *seqused_k,
                            void *p_d,
                            void *softmax_lse_d,
                            float p_dropout,
                            float softmax_scale,
                            int64_t window_size_left,
                            int64_t window_size_right,
                            const float softcap,
                            bool seqlenq_ngroups_swapped=false,
                            const bool unpadded_lse=false) {
    set_params_fprop(params,
        b,
        seqlen_q, seqlen_k,
        seqlen_q_rounded, seqlen_k_rounded,
        h, h_k,
        d, d_rounded,
        q, k, v, out,
        cu_seqlens_q_d,
        cu_seqlens_k_d,
        seqused_k,
        p_d,
        softmax_lse_d,
        p_dropout,
        softmax_scale,
        window_size_left,  // window_size_left
        window_size_right,  // window_size_right
        softcap,
        seqlenq_ngroups_swapped,
        unpadded_lse
    );
    params.block_count = block_count.const_data_ptr<int>();
    params.block_offset = block_offset.const_data_ptr<int>();
    params.column_count = column_count.const_data_ptr<int>();
    params.column_index = column_index.const_data_ptr<int>();
    STD_TORCH_CHECK(block_count.size(2) == block_offset.size(2));
    STD_TORCH_CHECK(column_index.size(2) == block_offset.size(2));
    STD_TORCH_CHECK(column_count.size(2) == column_index.size(2));
    params.NUM_ROWS = block_count.size(2);
    // params.NUM_ROWS should be equal to cdiv(seqlen_q, BLOCK_M), and BLOCK_M has to be 64 for now.
    constexpr int BLOCK_M = 64;
    int expected_num_rows = (seqlen_q + BLOCK_M - 1) / BLOCK_M;
    STD_TORCH_CHECK(params.NUM_ROWS == expected_num_rows);
    params.NNZ_S = block_offset.size(3);
    params.NNZ_V = column_index.size(3);
}

void run_mha_fwd_sparse(Flash_fwd_params_sparse &params, cudaStream_t stream, bool force_split_kernel=false) {
    STD_TORCH_CHECK(params.num_splits <= 1 && !force_split_kernel, "run_mha_fwd_sparse does not support splitkv.");
    STD_TORCH_CHECK(params.d == 128, "run_mha_fwd_sparse only supports headdim=128 for now to keep binary small.");
    FP16_SWITCH(!params.is_bf16, [&] {
        constexpr static int kHeadDim = 128;
        BOOL_SWITCH(params.is_causal, Is_causal, [&] {
            run_mha_fwd_sparse_<elem_type, kHeadDim, Is_causal>(params, stream);
        });
    });
}

std::vector<Tensor>
mha_fwd_sparse(Tensor q,         // batch_size x seqlen_q x num_heads x head_size
               const Tensor &k,         // batch_size x seqlen_k x num_heads_k x head_size
               const Tensor &v,         // batch_size x seqlen_k x num_heads_k x head_size
               const Tensor &block_count,
               const Tensor &block_offset,
               const Tensor &column_count,
               const Tensor &column_index,
               std::optional<Tensor> out_,             // batch_size x seqlen_q x num_heads x head_size
               std::optional<Tensor> alibi_slopes_, // num_heads or batch_size x num_heads
               const double p_dropout,
               const double softmax_scale,
               bool is_causal,
               const double softcap,
               const bool return_softmax,
               // Retained only for backwards-compat arg positioning; must be None.
               std::optional<Tensor> unused_generator_compat) {

    STD_TORCH_CHECK(!unused_generator_compat.has_value(),
                    "flash-attn: the RNG `generator` argument is no longer supported and must be None; "
                    "dropout (when enabled) uses the default CUDA generator.");

    auto [cc_major, cc_minor] = get_compute_capability(get_current_device());
    bool is_sm8x_min = cc_major >= 8;
    STD_TORCH_CHECK(is_sm8x_min, "FlashAttention only supports Ampere GPUs or newer.");

    auto q_dtype = q.scalar_type();
    STD_TORCH_CHECK(q_dtype == ScalarType::Half || q_dtype == ScalarType::BFloat16,
                "FlashAttention only support fp16 and bf16 data type");
    if (q_dtype == ScalarType::BFloat16) {
        STD_TORCH_CHECK(is_sm8x_min, "bfloat16 is only supported on Ampere GPUs or newer");
    }
    STD_TORCH_CHECK(k.scalar_type() == q_dtype, "query and key must have the same dtype");
    STD_TORCH_CHECK(v.scalar_type() == q_dtype, "query and value must have the same dtype");

    CHECK_DEVICE(q); CHECK_DEVICE(k); CHECK_DEVICE(v);

    STD_TORCH_CHECK(q.stride(-1) == 1, "Input tensor must have contiguous last dimension");
    STD_TORCH_CHECK(k.stride(-1) == 1, "Input tensor must have contiguous last dimension");
    STD_TORCH_CHECK(v.stride(-1) == 1, "Input tensor must have contiguous last dimension");

    const auto sizes = q.sizes();

    const int batch_size = sizes[0];
    int seqlen_q = sizes[1];
    int num_heads = sizes[2];
    const int head_size_og = sizes[3];
    const int seqlen_k = k.size(1);
    const int num_heads_k = k.size(2);
    STD_TORCH_CHECK(batch_size > 0, "batch size must be postive");
    STD_TORCH_CHECK(head_size_og <= 256, "FlashAttention forward only supports head dimension at most 256");
    STD_TORCH_CHECK(num_heads % num_heads_k == 0, "Number of heads in key/value must divide number of heads in query");

    if (softcap > 0.f) { STD_TORCH_CHECK(p_dropout == 0.f, "Softcapping does not support dropout for now"); }

    // causal=true is the same as causal=false in this case
    if (seqlen_q == 1 && !alibi_slopes_.has_value()) { is_causal = false; }

    int64_t window_size_left = -1;
    int64_t window_size_right = -1;
    if (is_causal) { window_size_right = 0; }

    CHECK_SHAPE(q, batch_size, seqlen_q, num_heads, head_size_og);
    CHECK_SHAPE(k, batch_size, seqlen_k, num_heads_k, head_size_og);
    CHECK_SHAPE(v, batch_size, seqlen_k, num_heads_k, head_size_og);

    Tensor q_padded, k_padded, v_padded;
    if (head_size_og % 8 != 0) {
        q_padded = torch::stable::pad(q, {0, 8 - head_size_og % 8});
        k_padded = torch::stable::pad(k, {0, 8 - head_size_og % 8});
        v_padded = torch::stable::pad(v, {0, 8 - head_size_og % 8});
    } else {
        q_padded = q;
        k_padded = k;
        v_padded = v;
    }

    Tensor out;
    if (out_.has_value()) {
        out = out_.value();
        STD_TORCH_CHECK(out.scalar_type() == q_dtype, "Output must have the same dtype as inputs");
        CHECK_DEVICE(out);
        STD_TORCH_CHECK(out.stride(-1) == 1, "Output tensor must have contiguous last dimension");
        CHECK_SHAPE(out, batch_size, sizes[1], sizes[2], head_size_og);
        if (head_size_og % 8 != 0) { out = torch::stable::empty_like(q_padded); }
    } else {
        out = torch::stable::empty_like(q_padded);
    }

    auto round_multiple = [](int x, int m) { return (x + m - 1) / m * m; };
    const int head_size = round_multiple(head_size_og, 8);
    const int head_size_rounded = round_multiple(head_size, 32);
    const int seqlen_q_rounded = round_multiple(seqlen_q, 128);
    const int seqlen_k_rounded = round_multiple(seqlen_k, 128);

    // Otherwise the kernel will be launched from cuda:0 device
    torch::stable::accelerator::DeviceGuard device_guard(q.get_device_index());

    auto softmax_lse = torch::stable::new_empty(q, {batch_size, num_heads, seqlen_q}, ScalarType::Float);
    Tensor p;
    // Only return softmax if there's dropout to reduce compilation time
    if (return_softmax) {
        STD_TORCH_CHECK(p_dropout > 0.0f, "return_softmax is only supported when p_dropout > 0.0");
        p = torch::stable::new_empty(q, {batch_size, num_heads, seqlen_q_rounded, seqlen_k_rounded});
    }

    Flash_fwd_params_sparse params;
    set_params_fprop_sparse(params,
                            batch_size,
                            seqlen_q, seqlen_k,
                            seqlen_q_rounded, seqlen_k_rounded,
                            num_heads, num_heads_k,
                            head_size, head_size_rounded,
                            q_padded, k_padded, v_padded,
                            block_count, block_offset,
                            column_count, column_index,
                            out,
                            /*cu_seqlens_q_d=*/nullptr,
                            /*cu_seqlens_k_d=*/nullptr,
                            /*seqused_k=*/nullptr,
                            return_softmax ? p.data_ptr() : nullptr,
                            softmax_lse.data_ptr(),
                            p_dropout,
                            softmax_scale,
                            window_size_left,
                            window_size_right,
                            softcap
                     );

    // Keep references to these tensors to extend their lifetime
    Tensor softmax_lse_accum, out_accum;
    std::tie(softmax_lse_accum, out_accum) = set_params_splitkv(
        params, batch_size, num_heads, head_size, seqlen_k, seqlen_q,
        head_size_rounded, p_dropout, /*num_splits*/ 1, get_num_sm(get_current_device()), q);

    // NOTE(woosuk): Commented out because they are not used in inference.
    // // number of times random will be generated per thread, to offset philox counter in thc random
    // // state
    // // We use a custom RNG that increases the offset by batch_size * nheads * 32.
    // int64_t counter_offset = params.b * params.h * 32;
    // auto options = torch::TensorOptions().dtype(torch::kFloat32).device(torch::kCUDA);
    // auto rng_state = torch::empty({2}, options.dtype(torch::kInt64));
    // // Forward kernel will populate memory with the seed and offset.
    // params.rng_state = reinterpret_cast<uint64_t*>(rng_state.data_ptr());

    // if (p_dropout > 0.0)  {
    //     auto gen = at::cuda::detail::getDefaultCUDAGenerator();
    //     // See Note [Acquire lock when using random generators]
    //     std::lock_guard<std::mutex> lock(gen.mutex());
    //     new (params.philox_args) at::PhiloxCudaState(gen.get<at::CUDAGeneratorImpl>()->philox_cuda_state(counter_offset));
    // }

    set_params_alibi(params, alibi_slopes_, batch_size, num_heads);

    if (seqlen_k > 0) {
        auto stream = get_current_cuda_stream(q);
        run_mha_fwd_sparse(params, stream);
    } else {
        // If seqlen_k == 0, then we have an empty tensor. We need to set the output to 0.
        torch::stable::zero_(out);
        torch::stable::fill_(softmax_lse, std::numeric_limits<float>::infinity());
    }

    if (head_size_og % 8 != 0) {
        out = torch::stable::narrow(out, out.dim() - 1, 0, head_size_og);
        if (out_.has_value()) { torch::stable::copy_(out_.value(), out); }
    }

    return {out, softmax_lse};
}

std::vector<Tensor>
mha_varlen_fwd_sparse(Tensor q,  // total_q x num_heads x head_size, total_q := \sum_{i=0}^{b} s_i
                      const Tensor &k,  // total_k x num_heads_k x head_size, total_k := \sum_{i=0}^{b} s_i.
                      const Tensor &v,  // total_k x num_heads_k x head_size, total_k := \sum_{i=0}^{b} s_i.
                      const Tensor &block_count,
                      const Tensor &block_offset,
                      const Tensor &column_count,
                      const Tensor &column_index,
                      std::optional<Tensor> out_, // total_q x num_heads x head_size, total_k := \sum_{i=0}^{b} s_i
                      const Tensor &cu_seqlens_q,  // b+1
                      const Tensor &cu_seqlens_k,  // b+1
                      std::optional<Tensor> seqused_k, // b. If given, only this many elements of each batch element's keys are used.
                      std::optional<Tensor> alibi_slopes_, // num_heads or b x num_heads
                      int64_t max_seqlen_q,
                      const int64_t max_seqlen_k,
                      const double p_dropout,
                      const double softmax_scale,
                      const bool zero_tensors,
                      bool is_causal,
                      const double softcap,
                      const bool return_softmax,
                      // Retained only for backwards-compat arg positioning; must be None.
                      std::optional<Tensor> unused_generator_compat) {

    STD_TORCH_CHECK(!unused_generator_compat.has_value(),
                    "flash-attn: the RNG `generator` argument is no longer supported and must be None; "
                    "dropout (when enabled) uses the default CUDA generator.");

    auto [cc_major, cc_minor] = get_compute_capability(get_current_device());
    bool is_sm8x_min = cc_major >= 8;
    STD_TORCH_CHECK(is_sm8x_min, "FlashAttention only supports Ampere GPUs or newer.");

    auto q_dtype = q.scalar_type();
    STD_TORCH_CHECK(q_dtype == ScalarType::Half || q_dtype == ScalarType::BFloat16,
                "FlashAttention only support fp16 and bf16 data type");
    if (q_dtype == ScalarType::BFloat16) {
        STD_TORCH_CHECK(is_sm8x_min, "bfloat16 is only supported on Ampere GPUs or newer");
    }
    STD_TORCH_CHECK(k.scalar_type() == q_dtype, "query and key must have the same dtype");
    STD_TORCH_CHECK(v.scalar_type() == q_dtype, "query and value must have the same dtype");
    STD_TORCH_CHECK(cu_seqlens_q.scalar_type() == ScalarType::Int, "cu_seqlens_q must have dtype int32");
    STD_TORCH_CHECK(cu_seqlens_k.scalar_type() == ScalarType::Int, "cu_seqlens_k must have dtype int32");

    CHECK_DEVICE(q); CHECK_DEVICE(k); CHECK_DEVICE(v);
    CHECK_DEVICE(cu_seqlens_q);
    CHECK_DEVICE(cu_seqlens_k);

    Tensor block_table;

    STD_TORCH_CHECK(q.stride(-1) == 1, "Input tensor must have contiguous last dimension");
    STD_TORCH_CHECK(k.stride(-1) == 1, "Input tensor must have contiguous last dimension");
    STD_TORCH_CHECK(v.stride(-1) == 1, "Input tensor must have contiguous last dimension");
    CHECK_CONTIGUOUS(cu_seqlens_q);
    CHECK_CONTIGUOUS(cu_seqlens_k);

    const auto sizes = q.sizes();

    const int batch_size = cu_seqlens_q.numel() - 1;
    int num_heads = sizes[1];
    const int head_size_og = sizes[2];
    const int num_heads_k = k.size(1);

    if (softcap > 0.f) { STD_TORCH_CHECK(p_dropout == 0.f, "Softcapping does not support dropout for now"); }

    if (max_seqlen_q == 1 && !alibi_slopes_.has_value()) { is_causal = false; }  // causal=true is the same as causal=false in this case

    int64_t window_size_left = -1;
    int64_t window_size_right = -1;
    if (is_causal) { window_size_right = 0; }

    void *cu_seqlens_q_d = cu_seqlens_q.data_ptr();

    const int total_q = q.size(0);

    STD_TORCH_CHECK(batch_size > 0, "batch size must be positive");
    STD_TORCH_CHECK(head_size_og <= 256, "FlashAttention forward only supports head dimension at most 256");
    STD_TORCH_CHECK(num_heads % num_heads_k == 0, "Number of heads in key/value must divide number of heads in query");

    CHECK_SHAPE(q, total_q, num_heads, head_size_og);
    const int total_k = k.size(0);
    CHECK_SHAPE(k, total_k, num_heads_k, head_size_og);
    CHECK_SHAPE(v, total_k, num_heads_k, head_size_og);


    CHECK_SHAPE(cu_seqlens_q, batch_size + 1);
    CHECK_SHAPE(cu_seqlens_k, batch_size + 1);
    if (seqused_k.has_value()){
        auto seqused_k_ = seqused_k.value();
        STD_TORCH_CHECK(seqused_k_.scalar_type() == ScalarType::Int, "seqused_k must have dtype int32");
        STD_TORCH_CHECK(seqused_k_.is_cuda(), "seqused_k must be on CUDA device");
        STD_TORCH_CHECK(seqused_k_.is_contiguous(), "seqused_k must be contiguous");
        CHECK_SHAPE(seqused_k_, batch_size);
    }

    Tensor q_padded, k_padded, v_padded;
    if (head_size_og % 8 != 0) {
        q_padded = torch::stable::pad(q, {0, 8 - head_size_og % 8});
        k_padded = torch::stable::pad(k, {0, 8 - head_size_og % 8});
        v_padded = torch::stable::pad(v, {0, 8 - head_size_og % 8});
    } else {
        q_padded = q;
        k_padded = k;
        v_padded = v;
    }

    Tensor out;
    if (out_.has_value()) {
        out = out_.value();
        STD_TORCH_CHECK(out.scalar_type() == q_dtype, "Output must have the same dtype as inputs");
        CHECK_DEVICE(out);
        STD_TORCH_CHECK(out.stride(-1) == 1, "Output tensor must have contiguous last dimension");
        CHECK_SHAPE(out, sizes[0], sizes[1], head_size_og);
        if (head_size_og % 8 != 0) { out = torch::stable::empty_like(q_padded); }
    } else {
        out = torch::stable::empty_like(q_padded);
    }

    auto round_multiple = [](int x, int m) { return (x + m - 1) / m * m; };
    const int head_size = round_multiple(head_size_og, 8);
    const int head_size_rounded = round_multiple(head_size, 32);
    const int seqlen_q_rounded = round_multiple(max_seqlen_q, 128);
    const int seqlen_k_rounded = round_multiple(max_seqlen_k, 128);

    // Otherwise the kernel will be launched from cuda:0 device
    torch::stable::accelerator::DeviceGuard device_guard(q.get_device_index());

    auto softmax_lse = torch::stable::new_empty(q, {num_heads, total_q}, ScalarType::Float);
    Tensor p;
    // Only return softmax if there's dropout to reduce compilation time
    if (return_softmax) {
        STD_TORCH_CHECK(p_dropout > 0.0f, "return_softmax is only supported when p_dropout > 0.0");
        p = torch::stable::new_empty(q, {batch_size, num_heads, seqlen_q_rounded, seqlen_k_rounded});
    }

    if (zero_tensors) {
        torch::stable::zero_(out);
        torch::stable::fill_(softmax_lse, -std::numeric_limits<float>::infinity());
        if (return_softmax) { torch::stable::zero_(p); }
    }

    Flash_fwd_params_sparse params;
    set_params_fprop_sparse(params,
                            batch_size,
                            max_seqlen_q, max_seqlen_k,
                            seqlen_q_rounded, seqlen_k_rounded,
                            num_heads, num_heads_k,
                            head_size, head_size_rounded,
                            q_padded, k_padded, v_padded,
                            block_count, block_offset,
                            column_count, column_index,
                            out,
                            cu_seqlens_q_d,
                            cu_seqlens_k.data_ptr(),
                            seqused_k.has_value() ? seqused_k.value().data_ptr() : nullptr,
                            return_softmax ? p.data_ptr() : nullptr,
                            softmax_lse.data_ptr(),
                            p_dropout,
                            softmax_scale,
                            window_size_left,
                            window_size_right,
                            softcap
                     );
    params.total_q = total_q;

    // Keep references to these tensors to extend their lifetime
    Tensor softmax_lse_accum, out_accum;

    // NOTE(woosuk): Commented out because they are not used in inference.
    // number of times random will be generated per thread, to offset philox counter in thc random
    // state
    // We use a custom RNG that increases the offset by batch_size * nheads * 32.
    // int64_t counter_offset = params.b * params.h * 32;
    // auto options = torch::TensorOptions().dtype(torch::kFloat32).device(torch::kCUDA);
    // auto rng_state = torch::empty({2}, options.dtype(torch::kInt64));
    // // Forward kernel will populate memory with the seed and offset.
    // params.rng_state = reinterpret_cast<uint64_t*>(rng_state.data_ptr());

    // if (p_dropout > 0.0)  {
    //     auto gen = at::cuda::detail::getDefaultCUDAGenerator();
    //     // See Note [Acquire lock when using random generators]
    //     std::lock_guard<std::mutex> lock(gen.mutex());
    //     new (params.philox_args) at::PhiloxCudaState(gen.get<at::CUDAGeneratorImpl>()->philox_cuda_state(counter_offset));
    // }

    set_params_alibi(params, alibi_slopes_, batch_size, num_heads);

    if (max_seqlen_k > 0) {
        auto stream = get_current_cuda_stream(q);
        run_mha_fwd_sparse(params, stream);
    } else {
        // If seqlen_k == 0, then we have an empty tensor. We need to set the output to 0.
        torch::stable::zero_(out);
        torch::stable::fill_(softmax_lse, std::numeric_limits<float>::infinity());
    }

    if (head_size_og % 8 != 0) {
        out = torch::stable::narrow(out, out.dim() - 1, 0, head_size_og);
        if (out_.has_value()) { torch::stable::copy_(out_.value(), out); }
    }

    return {out, softmax_lse};
}

} // namespace FLASH_NAMESPACE
